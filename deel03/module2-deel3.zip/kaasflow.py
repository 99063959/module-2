kaasGeel = input("is de kaas geel? ")

if kaasGeel == "ja":
    kaasGaten = input("zitten er gaten in? ")
else:
   kaasSchimmel = input("heeft de kaas blauwe schimmel? ")

if kaasGaten == "ja":
   kaasDuur = input("is de kaas belachelijk duur? ")
else:
   kaasSteen = input("is de kaas hard als steen? ")

if kaasSchimmel == "ja":
   kaasKorstRechts = input("heeft de kaas een korst? ")
else:
   kaasKorstLinks = input("heeft de kaas een korst? ")