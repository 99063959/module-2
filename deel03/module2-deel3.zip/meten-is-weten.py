getal1 = int(input("noem het eerste getal wat je wilt opgeven "))
print("het eerste getal wat je hebt opgegeven is",getal1)

getal2 = int(input("noem het tweede getal wat je wil opgeven "))
print("het tweede getal wat je hebt opgegeven is",getal2)

if getal1 > getal2:
    print("het eerste getal",getal1,"is het grootste getal")

elif getal2 > getal1:
    print(getal1,"is kleiner dan het tweede getal",getal2)

else:
    print("het eerste en tweede getal zijn gelijk")

